import React, { useEffect, useMemo, useState } from 'react';

const STORAGE_KEY = 'onecompiler_ionic_crud_task_board_bonus_v1';

function loadTasks() {
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    return saved ? JSON.parse(saved) : INITIAL_TASKS;
  } catch {
    return INITIAL_TASKS;
  }
}

const COLUMNS = [
  { id: 'todo', title: 'To Do' },
  { id: 'doing', title: 'Doing' },
  { id: 'review', title: 'Review' },
  { id: 'done', title: 'Done' },
  { id: 'rework', title: 'Rework' },
];

const TEAM_MEMBERS = [
  { id: 'm1', name: 'Raka Pratama', avatar: 'https://i.pravatar.cc/150?img=11' },
  { id: 'm2', name: 'Nadia Kusuma', avatar: 'https://i.pravatar.cc/150?img=5' },
  { id: 'm3', name: 'Bima Saputra', avatar: 'https://i.pravatar.cc/150?img=12' },
  { id: 'm4', name: 'Salsa Maharani', avatar: 'https://i.pravatar.cc/150?img=9' },
];

const COVER_PRESETS = [
  { label: 'Tanpa Cover', url: '' },
  {
    label: 'UI & Mobile Mockup',
    url: 'https://images.unsplash.com/photo-1551650975-87deedd944c3?auto=format&fit=crop&w=800&q=70',
  },
  {
    label: 'Code & Architecture',
    url: 'https://images.unsplash.com/photo-1555066931-4365d14bab8c?auto=format&fit=crop&w=800&q=70',
  },
  {
    label: 'Team Sprint Planning',
    url: 'https://images.unsplash.com/photo-1522071820081-009f0129c71c?auto=format&fit=crop&w=800&q=70',
  },
];

const LABELS = ['Feature', 'Bug', 'Issue', 'Undefined'];
const PRIORITIES = ['Low', 'Medium', 'High'];

const LABEL_COLOR = {
  Feature: 'primary',
  Bug: 'danger',
  Issue: 'warning',
  Undefined: 'medium',
};

const INITIAL_TASKS = [
  {
    id: 't-1',
    title: 'Setup autentikasi login & token refresh',
    description: 'Implementasi form login dan penyimpanan sesi di localStorage.',
    coverImage: COVER_PRESETS[2].url,
    columnId: 'todo',
    assigneeId: 'm1',
    dueDate: '2026-11-28',
    label: 'Feature',
    priority: 'High',
    subtasks: [
      { id: 's-1', title: 'Buat halaman login', completed: true },
      { id: 's-2', title: 'Validasi input form', completed: false },
      { id: 's-3', title: 'Simpan state sesi', completed: false },
    ],
    attachments: [{ id: 'a-1', name: 'auth-flow-spec.pdf' }],
  },
  {
    id: 't-2',
    title: 'Perbaiki layout card terpotong di layar kecil',
    description: 'Badge label dan tanggal jatuh tempo bertabrakan di layar sempit.',
    coverImage: COVER_PRESETS[1].url,
    columnId: 'doing',
    assigneeId: 'm2',
    dueDate: '2026-11-25',
    label: 'Bug',
    priority: 'High',
    subtasks: [
      { id: 's-4', title: 'Cek flex-wrap pada header card', completed: true },
      { id: 's-5', title: 'Uji di tampilan mobile', completed: true },
    ],
    attachments: [{ id: 'a-2', name: 'screenshot-bug.png' }],
  },
  {
    id: 't-3',
    title: 'Review alur validasi data board',
    description: 'Pastikan data task tetap utuh saat dipindah antar kolom.',
    coverImage: COVER_PRESETS[3].url,
    columnId: 'review',
    assigneeId: 'm3',
    dueDate: '2026-11-30',
    label: 'Issue',
    priority: 'Medium',
    subtasks: [
      { id: 's-6', title: 'Test drag & drop 5 kolom', completed: true },
      { id: 's-7', title: 'Test reload localStorage', completed: false },
    ],
    attachments: [],
  },
  {
    id: 't-4',
    title: 'Dokumentasi struktur komponen',
    description: 'Menyusun catatan singkat komponen utama aplikasi.',
    coverImage: '',
    columnId: 'done',
    assigneeId: 'm4',
    dueDate: '2026-11-20',
    label: 'Undefined',
    priority: 'Low',
    subtasks: [{ id: 's-8', title: 'Tulis catatan board', completed: true }],
    attachments: [{ id: 'a-3', name: 'arsitektur-ui.docx' }],
  },
];

function useIonicCdnAndAnimations() {
  useEffect(() => {
    if (!document.querySelector('link[data-ionic-cdn="true"]')) {
      const link = document.createElement('link');
      link.rel = 'stylesheet';
      link.href = 'https://cdn.jsdelivr.net/npm/@ionic/core/css/ionic.bundle.css';
      link.setAttribute('data-ionic-cdn', 'true');
      document.head.appendChild(link);
    }

    if (!document.querySelector('script[data-ionicons-cdn="true"]')) {
      const script = document.createElement('script');
      script.type = 'module';
      script.src = 'https://cdn.jsdelivr.net/npm/ionicons@7/dist/ionicons/ionicons.esm.js';
      script.setAttribute('data-ionicons-cdn', 'true');
      document.head.appendChild(script);
    }

    if (!document.querySelector('style[data-board-anim="true"]')) {
      const style = document.createElement('style');
      style.setAttribute('data-board-anim', 'true');
      style.textContent = `
        @keyframes toastSlideUp {
          from { opacity: 0; transform: translateY(14px) scale(0.97); }
          to { opacity: 1; transform: translateY(0) scale(1); }
        }
        @keyframes cardPopIn {
          from { opacity: 0; transform: translateY(6px); }
          to { opacity: 1; transform: translateY(0); }
        }
        .board-card {
          animation: cardPopIn 0.22s ease-out;
          transition: transform 0.18s ease, box-shadow 0.18s ease, opacity 0.18s ease;
        }
        .board-card:hover {
          transform: translateY(-3px);
          box-shadow: 0 8px 18px rgba(15, 23, 42, 0.12);
        }
        .board-card.is-dragging {
          opacity: 0.55;
          transform: scale(0.98) rotate(1deg);
        }
        .board-column {
          transition: background-color 0.18s ease, border-color 0.18s ease, transform 0.18s ease;
        }
        .board-column.is-drag-over {
          transform: translateY(-2px);
        }
        .board-toast {
          animation: toastSlideUp 0.22s ease-out;
        }
      `;
      document.head.appendChild(style);
    }
  }, []);
}

function ToastBanner({ toast, onDismiss }) {
  if (!toast) return null;

  const toneStyle = {
    created: { bg: '#0f766e', icon: 'checkmark-circle-outline' },
    updated: { bg: '#1d4ed8', icon: 'create-outline' },
    deleted: { bg: '#b91c1c', icon: 'trash-outline' },
    info: { bg: '#334155', icon: 'information-circle-outline' },
  }[toast.type || 'info'];

  return (
    <div
      className="board-toast"
      style={{
        position: 'fixed',
        bottom: '18px',
        right: '18px',
        zIndex: 10000,
        background: toneStyle.bg,
        color: '#fff',
        padding: '10px 14px',
        borderRadius: '10px',
        boxShadow: '0 10px 25px rgba(0,0,0,0.22)',
        display: 'flex',
        alignItems: 'center',
        gap: '8px',
        maxWidth: '340px',
        fontSize: '0.86rem',
        fontWeight: 500,
      }}
    >
      <ion-icon name={toneStyle.icon} style={{ fontSize: '1.15rem', flexShrink: 0 }}></ion-icon>
      <span style={{ flex: 1 }}>{toast.message}</span>
      <button
        type="button"
        onClick={onDismiss}
        style={{
          background: 'transparent',
          border: 'none',
          color: 'rgba(255,255,255,0.85)',
          cursor: 'pointer',
          padding: '0 2px',
          fontSize: '1rem',
        }}
      >
        ✕
      </button>
    </div>
  );
}

function TaskFormModal({
  isOpen,
  defaultColumnId,
  editingTask,
  onClose,
  onSave,
  onDelete,
}) {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [coverImage, setCoverImage] = useState('');
  const [columnId, setColumnId] = useState(defaultColumnId);
  const [assigneeId, setAssigneeId] = useState(TEAM_MEMBERS[0].id);
  const [dueDate, setDueDate] = useState('2026-11-30');
  const [label, setLabel] = useState('Feature');
  const [priority, setPriority] = useState('Medium');
  const [subtasks, setSubtasks] = useState([]);
  const [newSubtask, setNewSubtask] = useState('');
  const [attachments, setAttachments] = useState([]);
  const [newAttachment, setNewAttachment] = useState('');

  useEffect(() => {
    if (!isOpen) return;
    if (editingTask) {
      setTitle(editingTask.title);
      setDescription(editingTask.description || '');
      setCoverImage(editingTask.coverImage || '');
      setColumnId(editingTask.columnId);
      setAssigneeId(editingTask.assigneeId);
      setDueDate(editingTask.dueDate);
      setLabel(editingTask.label);
      setPriority(editingTask.priority);
      setSubtasks(editingTask.subtasks || []);
      setAttachments(editingTask.attachments || []);
    } else {
      setTitle('');
      setDescription('');
      setCoverImage('');
      setColumnId(defaultColumnId);
      setAssigneeId(TEAM_MEMBERS[0].id);
      setDueDate('2026-11-30');
      setLabel('Feature');
      setPriority('Medium');
      setSubtasks([]);
      setAttachments([]);
    }
    setNewSubtask('');
    setNewAttachment('');
  }, [isOpen, editingTask, defaultColumnId]);

  if (!isOpen) return null;

  const addSubtask = () => {
    const trimmed = newSubtask.trim();
    if (!trimmed) return;
    setSubtasks((prev) => [
      ...prev,
      { id: `sub-${Date.now()}`, title: trimmed, completed: false },
    ]);
    setNewSubtask('');
  };

  const toggleSubtask = (subId) => {
    setSubtasks((prev) =>
      prev.map((s) => (s.id === subId ? { ...s, completed: !s.completed } : s))
    );
  };

  const removeSubtask = (subId) => {
    setSubtasks((prev) => prev.filter((s) => s.id !== subId));
  };

  const addAttachment = () => {
    const trimmed = newAttachment.trim();
    if (!trimmed) return;
    setAttachments((prev) => [
      ...prev,
      { id: `att-${Date.now()}`, name: trimmed },
    ]);
    setNewAttachment('');
  };

  const removeAttachment = (attId) => {
    setAttachments((prev) => prev.filter((a) => a.id !== attId));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!title.trim()) return;

    onSave(
      {
        id: editingTask ? editingTask.id : `task-${Date.now()}`,
        title: title.trim(),
        description: description.trim(),
        coverImage: coverImage.trim(),
        columnId,
        assigneeId,
        dueDate,
        label,
        priority,
        subtasks,
        attachments,
      },
      !editingTask
    );
    onClose();
  };

  return (
    <div
      style={{
        position: 'fixed',
        inset: 0,
        background: 'rgba(0, 0, 0, 0.45)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        zIndex: 9999,
        padding: '12px',
      }}
      onClick={onClose}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        style={{
          background: '#fff',
          borderRadius: '14px',
          width: '100%',
          maxWidth: '520px',
          maxHeight: '90vh',
          overflowY: 'auto',
          boxShadow: '0 14px 36px rgba(0,0,0,0.22)',
        }}
      >
        <ion-header>
          <ion-toolbar>
            <ion-title>{editingTask ? 'Edit Task' : 'Tambah Task Baru'}</ion-title>
            <ion-button slot="end" fill="clear" onClick={onClose}>
              Tutup
            </ion-button>
          </ion-toolbar>
        </ion-header>

        <form onSubmit={handleSubmit} style={{ padding: '16px' }}>
          <div style={{ marginBottom: '12px' }}>
            <label style={{ display: 'block', fontWeight: 600, marginBottom: '4px' }}>
              Judul Task *
            </label>
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Contoh: Integrasi API pembayaran"
              style={{
                width: '100%',
                padding: '8px 10px',
                borderRadius: '8px',
                border: '1px solid #cbd5e1',
              }}
            />
          </div>

          <div style={{ marginBottom: '12px' }}>
            <label style={{ display: 'block', fontWeight: 600, marginBottom: '4px' }}>
              Deskripsi
            </label>
            <textarea
              rows={2}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Detail task..."
              style={{
                width: '100%',
                padding: '8px 10px',
                borderRadius: '8px',
                border: '1px solid #cbd5e1',
              }}
            />
          </div>

          {/* Cover Image (Bonus) */}
          <div style={{ marginBottom: '12px' }}>
            <label style={{ display: 'block', fontWeight: 600, marginBottom: '4px' }}>
              Cover Image (Preset / URL Dummy)
            </label>
            <select
              value={
                COVER_PRESETS.some((p) => p.url === coverImage) ? coverImage : 'custom'
              }
              onChange={(e) => {
                if (e.target.value !== 'custom') setCoverImage(e.target.value);
              }}
              style={{
                width: '100%',
                padding: '8px',
                borderRadius: '8px',
                border: '1px solid #cbd5e1',
                marginBottom: '6px',
              }}
            >
              {COVER_PRESETS.map((p) => (
                <option key={p.label} value={p.url}>
                  {p.label}
                </option>
              ))}
              <option value="custom">URL Kustom...</option>
            </select>

            <input
              type="text"
              value={coverImage}
              onChange={(e) => setCoverImage(e.target.value)}
              placeholder="Tempel URL gambar cover atau biarkan kosong"
              style={{
                width: '100%',
                padding: '7px 10px',
                borderRadius: '8px',
                border: '1px solid #cbd5e1',
                fontSize: '0.84rem',
              }}
            />

            {coverImage && (
              <div style={{ marginTop: '8px', position: 'relative' }}>
                <img
                  src={coverImage}
                  alt="Preview Cover"
                  style={{
                    width: '100%',
                    height: '120px',
                    objectFit: 'cover',
                    borderRadius: '8px',
                    border: '1px solid #e2e8f0',
                  }}
                />
                <button
                  type="button"
                  onClick={() => setCoverImage('')}
                  style={{
                    position: 'absolute',
                    top: '6px',
                    right: '6px',
                    background: 'rgba(15, 23, 42, 0.75)',
                    color: '#fff',
                    border: 'none',
                    borderRadius: '6px',
                    padding: '3px 8px',
                    fontSize: '0.75rem',
                    cursor: 'pointer',
                  }}
                >
                  Hapus Cover
                </button>
              </div>
            )}
          </div>

          <div
            style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(2, minmax(0, 1fr))',
              gap: '10px',
              marginBottom: '12px',
            }}
          >
            <div>
              <label style={{ display: 'block', fontWeight: 600, marginBottom: '4px' }}>
                Kolom
              </label>
              <select
                value={columnId}
                onChange={(e) => setColumnId(e.target.value)}
                style={{ width: '100%', padding: '8px', borderRadius: '8px', border: '1px solid #cbd5e1' }}
              >
                {COLUMNS.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.title}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label style={{ display: 'block', fontWeight: 600, marginBottom: '4px' }}>
                Assignee
              </label>
              <select
                value={assigneeId}
                onChange={(e) => setAssigneeId(e.target.value)}
                style={{ width: '100%', padding: '8px', borderRadius: '8px', border: '1px solid #cbd5e1' }}
              >
                {TEAM_MEMBERS.map((m) => (
                  <option key={m.id} value={m.id}>
                    {m.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label style={{ display: 'block', fontWeight: 600, marginBottom: '4px' }}>
                Due Date
              </label>
              <input
                type="date"
                value={dueDate}
                onChange={(e) => setDueDate(e.target.value)}
                style={{ width: '100%', padding: '7px 8px', borderRadius: '8px', border: '1px solid #cbd5e1' }}
              />
            </div>

            <div>
              <label style={{ display: 'block', fontWeight: 600, marginBottom: '4px' }}>
                Label
              </label>
              <select
                value={label}
                onChange={(e) => setLabel(e.target.value)}
                style={{ width: '100%', padding: '8px', borderRadius: '8px', border: '1px solid #cbd5e1' }}
              >
                {LABELS.map((l) => (
                  <option key={l} value={l}>
                    {l}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div style={{ marginBottom: '14px' }}>
            <label style={{ display: 'block', fontWeight: 600, marginBottom: '4px' }}>
              Priority
            </label>
            <select
              value={priority}
              onChange={(e) => setPriority(e.target.value)}
              style={{ width: '100%', padding: '8px', borderRadius: '8px', border: '1px solid #cbd5e1' }}
            >
              {PRIORITIES.map((p) => (
                <option key={p} value={p}>
                  {p}
                </option>
              ))}
            </select>
          </div>

          {/* Checklist Subtask */}
          <div style={{ marginBottom: '14px' }}>
            <div style={{ fontWeight: 600, marginBottom: '6px' }}>Checklist Subtask</div>
            <div style={{ display: 'flex', gap: '6px', marginBottom: '8px' }}>
              <input
                type="text"
                value={newSubtask}
                onChange={(e) => setNewSubtask(e.target.value)}
                placeholder="Tambah subtask..."
                style={{ flex: 1, padding: '7px 10px', borderRadius: '8px', border: '1px solid #cbd5e1' }}
              />
              <ion-button type="button" onClick={addSubtask}>
                <ion-icon name="add-outline"></ion-icon>
              </ion-button>
            </div>

            {subtasks.map((sub) => (
              <div
                key={sub.id}
                style={{
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'space-between',
                  padding: '4px 0',
                }}
              >
                <label style={{ display: 'flex', alignItems: 'center', gap: '8px', cursor: 'pointer' }}>
                  <input
                    type="checkbox"
                    checked={sub.completed}
                    onChange={() => toggleSubtask(sub.id)}
                  />
                  <span style={{ textDecoration: sub.completed ? 'line-through' : 'none' }}>
                    {sub.title}
                  </span>
                </label>
                <button
                  type="button"
                  onClick={() => removeSubtask(sub.id)}
                  style={{ background: 'transparent', border: 'none', color: '#dc2626', cursor: 'pointer' }}
                >
                  <ion-icon name="trash-outline"></ion-icon>
                </button>
              </div>
            ))}
          </div>

          {/* Dummy Attachments */}
          <div style={{ marginBottom: '16px' }}>
            <div style={{ fontWeight: 600, marginBottom: '6px' }}>Attachments (Dummy)</div>
            <div style={{ display: 'flex', gap: '6px', marginBottom: '8px' }}>
              <input
                type="text"
                value={newAttachment}
                onChange={(e) => setNewAttachment(e.target.value)}
                placeholder="Nama file, mis. desain-ui.png"
                style={{ flex: 1, padding: '7px 10px', borderRadius: '8px', border: '1px solid #cbd5e1' }}
              />
              <ion-button type="button" fill="outline" onClick={addAttachment}>
                <ion-icon name="attach-outline"></ion-icon>
              </ion-button>
            </div>

            <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px' }}>
              {attachments.map((att) => (
                <ion-chip key={att.id}>
                  <ion-icon name="attach-outline"></ion-icon>
                  <ion-label>{att.name}</ion-label>
                  <ion-icon
                    name="close-circle"
                    style={{ cursor: 'pointer' }}
                    onClick={() => removeAttachment(att.id)}
                  ></ion-icon>
                </ion-chip>
              ))}
            </div>
          </div>

          <div
            style={{
              position: 'sticky',
              bottom: '-16px',
              display: 'flex',
              gap: '8px',
              margin: '0 -16px -16px',
              padding: '12px 16px',
              background: '#fff',
              borderTop: '1px solid #e2e8f0',
              zIndex: 1,
            }}
          >
            <button
              type="submit"
              style={{
                flex: 1,
                minHeight: '44px',
                border: 'none',
                borderRadius: '8px',
                background: '#3880ff',
                color: '#fff',
                fontSize: '1rem',
                fontWeight: 600,
                cursor: 'pointer',
              }}
            >
              {editingTask ? 'Simpan Perubahan' : 'Simpan Task'}
            </button>
            {editingTask && onDelete && (
              <button
                type="button"
                onClick={() => {
                  onDelete(editingTask.id);
                  onClose();
                }}
                aria-label="Hapus task"
                style={{
                  minWidth: '44px',
                  border: '1px solid #dc2626',
                  borderRadius: '8px',
                  background: '#fff',
                  color: '#dc2626',
                  fontSize: '1.15rem',
                  cursor: 'pointer',
                }}
              >
                <ion-icon name="trash-outline"></ion-icon>
              </button>
            )}
          </div>
        </form>
      </div>
    </div>
  );
}

export default function App() {
  useIonicCdnAndAnimations();

  const [tasks, setTasks] = useState(loadTasks);

  const [searchText, setSearchText] = useState('');
  const [filterAssignee, setFilterAssignee] = useState('ALL');
  const [filterLabel, setFilterLabel] = useState('ALL');
  const [filterDue, setFilterDue] = useState('ALL');

  const [draggedTaskId, setDraggedTaskId] = useState(null);
  const [dragOverColumn, setDragOverColumn] = useState(null);

  const [modalOpen, setModalOpen] = useState(false);
  const [defaultCol, setDefaultCol] = useState('todo');
  const [editingTask, setEditingTask] = useState(null);

  const [toast, setToast] = useState(null);

  const showToast = (message, type = 'info') => {
    setToast({ id: Date.now(), message, type });
  };

  useEffect(() => {
    if (!toast) return;
    const timer = setTimeout(() => setToast(null), 2800);
    return () => clearTimeout(timer);
  }, [toast]);

  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(tasks));
    } catch {
      // Abaikan jika storage tidak tersedia
    }
  }, [tasks]);

  const memberMap = useMemo(
    () => Object.fromEntries(TEAM_MEMBERS.map((m) => [m.id, m])),
    []
  );

  const filteredTasks = useMemo(() => {
    const todayStr = new Date().toISOString().slice(0, 10);
    const q = searchText.trim().toLowerCase();

    return tasks.filter((t) => {
      const member = memberMap[t.assigneeId];
      const matchesText =
        !q ||
        t.title.toLowerCase().includes(q) ||
        (t.description || '').toLowerCase().includes(q) ||
        (member?.name.toLowerCase().includes(q) ?? false);

      const matchesAssignee =
        filterAssignee === 'ALL' || t.assigneeId === filterAssignee;
      const matchesLabel = filterLabel === 'ALL' || t.label === filterLabel;
      const matchesDue =
        filterDue === 'ALL' ||
        (filterDue === 'OVERDUE' && t.dueDate < todayStr) ||
        (filterDue === 'UPCOMING' && t.dueDate >= todayStr);

      return matchesText && matchesAssignee && matchesLabel && matchesDue;
    });
  }, [tasks, searchText, filterAssignee, filterLabel, filterDue, memberMap]);

  const handleSaveTask = (saved, isNew) => {
    setTasks((prev) =>
      isNew ? [...prev, saved] : prev.map((t) => (t.id === saved.id ? saved : t))
    );
    showToast(
      isNew ? `Task "${saved.title}" dibuat.` : `Task "${saved.title}" diperbarui.`,
      isNew ? 'created' : 'updated'
    );
  };

  const handleDeleteTask = (taskId) => {
    const target = tasks.find((t) => t.id === taskId);
    setTasks((prev) => prev.filter((t) => t.id !== taskId));
    showToast(
      target ? `Task "${target.title}" dihapus.` : 'Task dihapus.',
      'deleted'
    );
  };

  const handleToggleSubtaskOnCard = (e, taskId, subtaskId) => {
    e.stopPropagation();
    const checked = e.target.checked;
    setTasks((prev) =>
      prev.map((t) => {
        if (t.id !== taskId) return t;
        return {
          ...t,
          subtasks: t.subtasks.map((s) =>
            s.id === subtaskId ? { ...s, completed: checked } : s
          ),
        };
      })
    );
  };

  const handleDropOnColumn = (targetColId) => {
    if (!draggedTaskId) return;
    const movingTask = tasks.find((t) => t.id === draggedTaskId);
    const colTitle = COLUMNS.find((c) => c.id === targetColId)?.title || targetColId;

    setTasks((prev) =>
      prev.map((t) =>
        t.id === draggedTaskId ? { ...t, columnId: targetColId } : t
      )
    );

    if (movingTask && movingTask.columnId !== targetColId) {
      showToast(`"${movingTask.title}" dipindah ke ${colTitle}.`, 'updated');
    }

    setDraggedTaskId(null);
    setDragOverColumn(null);
  };

  const handleResetDemo = () => {
    setTasks(INITIAL_TASKS);
    showToast('Data board dikembalikan ke awal.', 'info');
  };

  return (
    <ion-app>
      <ion-header>
        <ion-toolbar color="primary">
          <ion-title>Task Board</ion-title>
          <ion-button slot="end" fill="clear" color="light" onClick={handleResetDemo}>
            <ion-icon slot="icon-only" name="refresh-outline"></ion-icon>
          </ion-button>
          <ion-button
            slot="end"
            fill="solid"
            color="light"
            onClick={() => {
              setEditingTask(null);
              setDefaultCol('todo');
              setModalOpen(true);
            }}
          >
            <ion-icon slot="start" name="add-outline"></ion-icon>
            Task Baru
          </ion-button>
        </ion-toolbar>

        <ion-toolbar>
          <div
            style={{
              display: 'flex',
              flexWrap: 'wrap',
              gap: '8px',
              padding: '8px 12px',
              alignItems: 'center',
            }}
          >
            <input
              type="text"
              value={searchText}
              onChange={(e) => setSearchText(e.target.value)}
              placeholder="Cari judul, deskripsi, atau assignee..."
              style={{
                flex: '1 1 220px',
                padding: '7px 10px',
                borderRadius: '8px',
                border: '1px solid #cbd5e1',
              }}
            />

            <select
              value={filterAssignee}
              onChange={(e) => setFilterAssignee(e.target.value)}
              style={{ padding: '7px 8px', borderRadius: '8px', border: '1px solid #cbd5e1' }}
            >
              <option value="ALL">Semua Assignee</option>
              {TEAM_MEMBERS.map((m) => (
                <option key={m.id} value={m.id}>
                  {m.name}
                </option>
              ))}
            </select>

            <select
              value={filterLabel}
              onChange={(e) => setFilterLabel(e.target.value)}
              style={{ padding: '7px 8px', borderRadius: '8px', border: '1px solid #cbd5e1' }}
            >
              <option value="ALL">Semua Label</option>
              {LABELS.map((l) => (
                <option key={l} value={l}>
                  {l}
                </option>
              ))}
            </select>

            <select
              value={filterDue}
              onChange={(e) => setFilterDue(e.target.value)}
              style={{ padding: '7px 8px', borderRadius: '8px', border: '1px solid #cbd5e1' }}
            >
              <option value="ALL">Semua Due Date</option>
              <option value="OVERDUE">Terlewat (Overdue)</option>
              <option value="UPCOMING">Akan Datang</option>
            </select>
          </div>
        </ion-toolbar>
      </ion-header>

      <ion-content color="light">
        <div
          style={{
            display: 'flex',
            gap: '14px',
            padding: '14px',
            overflowX: 'auto',
            alignItems: 'flex-start',
            minHeight: '100%',
          }}
        >
          {COLUMNS.map((col) => {
            const colTasks = filteredTasks.filter((t) => t.columnId === col.id);
            const isOver = dragOverColumn === col.id;

            return (
              <div
                key={col.id}
                className={`board-column ${isOver ? 'is-drag-over' : ''}`}
                onDragOver={(e) => {
                  e.preventDefault();
                  if (dragOverColumn !== col.id) setDragOverColumn(col.id);
                }}
                onDragLeave={() => setDragOverColumn(null)}
                onDrop={() => handleDropOnColumn(col.id)}
                style={{
                  flex: '0 0 300px',
                  background: isOver ? '#e0f2fe' : '#eef1f5',
                  borderRadius: '12px',
                  padding: '10px',
                  border: isOver
                    ? '2px dashed var(--ion-color-primary)'
                    : '1px solid #dce1e7',
                }}
              >
                <div
                  style={{
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                    marginBottom: '8px',
                    padding: '0 4px',
                  }}
                >
                  <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                    <strong>{col.title}</strong>
                    <ion-badge color="medium">{colTasks.length}</ion-badge>
                  </div>
                  <ion-button
                    size="small"
                    fill="clear"
                    onClick={() => {
                      setEditingTask(null);
                      setDefaultCol(col.id);
                      setModalOpen(true);
                    }}
                  >
                    <ion-icon slot="icon-only" name="add-outline"></ion-icon>
                  </ion-button>
                </div>

                {colTasks
                  .reduce((groups, task) => {
                    let group = groups.find((item) => item.assigneeId === task.assigneeId);
                    if (!group) {
                      group = { assigneeId: task.assigneeId, tasks: [] };
                      groups.push(group);
                    }
                    group.tasks.push(task);
                    return groups;
                  }, [])
                  .map((group, groupIndex) => (
                    <div
                      key={group.assigneeId || 'unassigned'}
                      style={{
                        marginTop: groupIndex === 0 ? 0 : '14px',
                        padding: '8px',
                        background: '#f8fafc',
                        border: '1px solid #dce1e7',
                        borderRadius: '10px',
                        boxShadow: '0 2px 5px rgba(15, 23, 42, 0.04)',
                      }}
                    >
                      <div
                        style={{
                          display: 'flex',
                          alignItems: 'center',
                          gap: '7px',
                          margin: groupIndex === 0 ? '4px 2px 8px' : '0 2px 10px',
                          color: '#475569',
                          fontSize: '0.78rem',
                          fontWeight: 600,
                        }}
                      >
                        {memberMap[group.assigneeId] && (
                          <ion-avatar style={{ width: '20px', height: '20px' }}>
                            <img
                              src={memberMap[group.assigneeId].avatar}
                              alt={memberMap[group.assigneeId].name}
                            />
                          </ion-avatar>
                        )}
                        <span>{memberMap[group.assigneeId]?.name || 'Unassigned'}</span>
                        <span style={{ marginLeft: 'auto', color: '#64748b', fontWeight: 400 }}>
                          {group.tasks.length} task
                        </span>
                      </div>
                      {group.tasks.map((task) => {
                  const assignee = memberMap[task.assigneeId];
                  const doneCount = (task.subtasks || []).filter((s) => s.completed).length;
                  const totalSub = (task.subtasks || []).length;
                  const progress = totalSub > 0 ? doneCount / totalSub : 0;
                  const isDragging = draggedTaskId === task.id;

                  return (
                    <ion-card
                      key={task.id}
                      className={`board-card ${isDragging ? 'is-dragging' : ''}`}
                      draggable
                      onDragStart={() => setDraggedTaskId(task.id)}
                      onDragEnd={() => {
                        setDraggedTaskId(null);
                        setDragOverColumn(null);
                      }}
                      onClick={() => {
                        setEditingTask(task);
                        setDefaultCol(task.columnId);
                        setModalOpen(true);
                      }}
                      style={{ margin: '0 0 10px 0', cursor: 'grab' }}
                    >
                      {task.coverImage && (
                        <img
                          src={task.coverImage}
                          alt={task.title}
                          style={{
                            width: '100%',
                            height: '115px',
                            objectFit: 'cover',
                            display: 'block',
                          }}
                        />
                      )}

                      <ion-card-header style={{ paddingBottom: '6px' }}>
                        <div
                          style={{
                            display: 'flex',
                            justifyContent: 'space-between',
                            alignItems: 'center',
                            gap: '6px',
                          }}
                        >
                          <div style={{ display: 'flex', gap: '6px', flexWrap: 'wrap' }}>
                            <ion-badge color={LABEL_COLOR[task.label] || 'medium'}>
                              {task.label}
                            </ion-badge>
                            <ion-badge color="light">{task.priority}</ion-badge>
                          </div>

                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleDeleteTask(task.id);
                            }}
                            style={{
                              background: 'transparent',
                              border: 'none',
                              color: '#dc2626',
                              cursor: 'pointer',
                              fontSize: '1rem',
                            }}
                          >
                            <ion-icon name="trash-outline"></ion-icon>
                          </button>
                        </div>

                        <div style={{ fontWeight: 600, fontSize: '0.98rem', marginTop: '6px' }}>
                          {task.title}
                        </div>
                      </ion-card-header>

                      <ion-card-content style={{ paddingTop: 0 }}>
                        {task.description && (
                          <p style={{ fontSize: '0.84rem', margin: '0 0 10px 0', color: '#475569' }}>
                            {task.description}
                          </p>
                        )}

                        {totalSub > 0 && (
                          <div style={{ marginBottom: '10px' }} onClick={(e) => e.stopPropagation()}>
                            <div
                              style={{
                                display: 'flex',
                                justifyContent: 'space-between',
                                fontSize: '0.76rem',
                                marginBottom: '4px',
                              }}
                            >
                              <span>Checklist</span>
                              <span>
                                {doneCount}/{totalSub} ({Math.round(progress * 100)}%)
                              </span>
                            </div>
                            <ion-progress-bar value={progress}></ion-progress-bar>

                            <div style={{ marginTop: '6px' }}>
                              {task.subtasks.map((sub) => (
                                <label
                                  key={sub.id}
                                  style={{
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: '6px',
                                    fontSize: '0.79rem',
                                    padding: '2px 0',
                                    cursor: 'pointer',
                                  }}
                                >
                                  <input
                                    type="checkbox"
                                    checked={sub.completed}
                                    onChange={(e) => handleToggleSubtaskOnCard(e, task.id, sub.id)}
                                  />
                                  <span style={{ textDecoration: sub.completed ? 'line-through' : 'none' }}>
                                    {sub.title}
                                  </span>
                                </label>
                              ))}
                            </div>
                          </div>
                        )}

                        {(task.attachments || []).length > 0 && (
                          <div
                            style={{
                              display: 'flex',
                              flexWrap: 'wrap',
                              gap: '6px',
                              marginBottom: '10px',
                            }}
                          >
                            {task.attachments.map((att) => (
                              <span
                                key={att.id}
                                style={{
                                  display: 'inline-flex',
                                  alignItems: 'center',
                                  gap: '4px',
                                  fontSize: '0.74rem',
                                  background: '#f1f5f9',
                                  padding: '3px 7px',
                                  borderRadius: '6px',
                                }}
                              >
                                <ion-icon name="attach-outline"></ion-icon>
                                {att.name}
                              </span>
                            ))}
                          </div>
                        )}

                        <div
                          style={{
                            display: 'flex',
                            justifyContent: 'space-between',
                            alignItems: 'center',
                            borderTop: '1px solid #e2e8f0',
                            paddingTop: '8px',
                            fontSize: '0.78rem',
                          }}
                        >
                          <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                            {assignee && (
                              <ion-avatar style={{ width: '22px', height: '22px' }}>
                                <img src={assignee.avatar} alt={assignee.name} />
                              </ion-avatar>
                            )}
                            <span>{assignee?.name || 'Unassigned'}</span>
                          </div>

                          <div style={{ display: 'inline-flex', alignItems: 'center', gap: '4px', color: '#64748b' }}>
                            <ion-icon name="calendar-outline"></ion-icon>
                            <span>{task.dueDate}</span>
                          </div>
                        </div>
                      </ion-card-content>
                    </ion-card>
                      );
                      })}
                    </div>
                  ))}
              </div>
            );
          })}
        </div>

        <TaskFormModal
          isOpen={modalOpen}
          defaultColumnId={defaultCol}
          editingTask={editingTask}
          onClose={() => setModalOpen(false)}
          onSave={handleSaveTask}
          onDelete={handleDeleteTask}
        />

        <ToastBanner toast={toast} onDismiss={() => setToast(null)} />
      </ion-content>
    </ion-app>
  );
}